import type { Category } from '../types/index.ts'

export const categories : Category[] = [
  { id: 1, name: 'Comida'},
  { id: 2, name: 'Ejercicio'}
]